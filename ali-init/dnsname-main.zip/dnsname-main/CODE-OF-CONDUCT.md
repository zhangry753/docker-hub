## The dnsname Project Community Code of Conduct

The dnsname project follows the [Containers Community Code of Conduct](https://github.com/containers/common/blob/main/CODE-OF-CONDUCT.md).
